
### Micro benchmark 1

Useage

	script(op)
	% op can be one of [0,1,2,3]
	% N0 = 10000; % 0
	% N1 = 20000; % 1
	% N2 = 40000; % 2
	% N3 = 80000; % 3
	
Files

- script
  - run\_micro1\_*.m
    - micro1\_*.m