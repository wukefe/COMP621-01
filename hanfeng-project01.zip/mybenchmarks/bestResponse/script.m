disp('(100,50)');
singleRun(100,50)
disp('(200,50)');
singleRun(200,50)
disp('(200,100)');
singleRun(200,100)
disp('(400,100)');
singleRun(400,100)