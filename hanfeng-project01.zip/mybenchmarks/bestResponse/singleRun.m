function singleRun(x, y)
	singleRun_new(x, y);
	singleRun_vector(x, y);
	singleRun_parfor(x, y);
	singleRun_opt(x, y);
end