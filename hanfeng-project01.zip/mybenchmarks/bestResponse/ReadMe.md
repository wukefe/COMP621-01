### BestResponse benchmark

Usage

	script()
	% singleRun(x, y)
	% N is 100; rng is 111
	% x and y can be
	%   (100,50), (200,50), (200,100), (400,100)
	
Files

- singleRun.m
  - singleRun_new.m
  - singleRun_vector.m
  - singleRun_parfor.m
  - randMatrixBestResponse_new.m
  - randMatrixBestResponse_vector.m
  - randMatrixBestResponse_parfor.m

Log file

- log.txt