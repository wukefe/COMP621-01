
### Micro benchmark 2

Useage

	script(op)
	% op can be one of [0,1,2,3]
	% N0 = 100000; % 0
	% N1 = 200000; % 1
	% N2 = 400000; % 2
	% N3 = 800000; % 3
	
Files

- script
  - run\_micro2\_*.m
    - micro2\_*.m